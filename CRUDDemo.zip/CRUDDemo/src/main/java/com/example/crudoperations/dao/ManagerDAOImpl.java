package com.example.crudoperations.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.crudoperations.bean.ManagerBean;

@Repository
public class ManagerDAOImpl implements ManagerDAO{
	@Autowired
	private EntityManager entityManager;

	@Override
	public boolean checkIfExistInDb(String username, String password) {
		Session currentSession = entityManager.unwrap(Session.class);
		Query query = currentSession.createQuery("from ManagerBean where email = :e and password =:p");
		query.setParameter("e", username);
		query.setParameter("p", password);
		List list = query.list();
		if(list.isEmpty()) {
			return false;
		}else {
			return true;			
		}
	}

	@Override
	public List<ManagerBean> get() {
		Session currentSession = entityManager.unwrap(Session.class);
		Query<ManagerBean> query= currentSession.createQuery("from ManagerBean",ManagerBean.class);
		List<ManagerBean> mngrList = query.getResultList();
		return mngrList;
	}

	@Override
	public ManagerBean get(int id) {
		Session currentSession = entityManager.unwrap(Session.class);
		ManagerBean manager = currentSession.get(ManagerBean.class, id);
		return manager;
	}

	@Override
	public void save(ManagerBean manager) {
		Session currentSession = entityManager.unwrap(Session.class);
		currentSession.saveOrUpdate(manager);
	}

	@Override
	public void delete(int id) {
		Session currentSession = entityManager.unwrap(Session.class);
		ManagerBean manager = currentSession.get(ManagerBean.class, id);
		currentSession.delete(manager);
	}

	
}
