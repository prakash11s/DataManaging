package com.example.crudoperations.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.crudoperations.bean.ManagerBean;
import com.example.crudoperations.dao.ManagerDAO;
import com.example.crudoperations.dao.ManagerDAOImpl;
import com.example.crudoperations.security.SecurityFilter;
import com.example.crudoperations.service.ManagerService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/manager")
public class ManagerController {
	@Autowired
	ManagerDAOImpl managerRepository;

	@Autowired
	private ManagerService managerService;
	
	@Autowired
	private ManagerDAO mangerDao;

	/*
	 * @PostMapping("/saveManager") public ManagerBean saveManager(@RequestBody
	 * ManagerBean manager) { return managerRepository.save(manager); }
	 */

	@PostMapping("/saveManager")
	public ManagerBean save(@RequestBody ManagerBean manager) {
		managerService.save(manager);
		return manager;
	}

	// authentication
	@RequestMapping(value = "/checkIfExists", method = RequestMethod.GET)
	public boolean checkIfExistsInDb(HttpServletRequest request, HttpServletResponse response) {
		SecurityFilter securityFilter = new SecurityFilter();
		String[] values = securityFilter.checkAuthentication(request);
		String bausername = values[0];
		String bapassword = values[1];
		boolean isManager = false;
		isManager = mangerDao.checkIfExistInDb(bausername, bapassword);
		return isManager;
	}
}
