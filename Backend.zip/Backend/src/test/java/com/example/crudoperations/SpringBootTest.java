package com.example.crudoperations;

public @interface SpringBootTest {

}
